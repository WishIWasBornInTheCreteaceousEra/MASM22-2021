PHD THESIS TEMPLATE --- ASTRONOMY AT LUND UNIVERSITY
====================================================

1) 

You definitely want to use the correct (official) fonts (typefaces)
for a PhD thesis at Lund University. If you are using Overleaf, the
font files are already included in the template. If you are using
LaTeX on your own computer, you have to install them.

To be able to use the correct fonts, you have to use XeLaTeX. You can
do that in Overleaf or on  your own computer.


1) Go to http://www.lu.se/bildbank, login.
2) Download Fonts/LU profil
3) Unzip
4) Install fonts:

-- On Linux
Copy the font directories and update font cache.

$ sudo cp -r AdobeGaramondPro /usr/share/fonts/opentype/
$ sudo cp -r FrutigerLTStd /usr/share/fonts/opentype/
$ sudo fc-cache -f -v


-- On Mac
Copy directories AdobeGaramondPro and FrutigerLTStd to
Harddrive/Library/Fonts/


-- On Overleaf
The main directory already has the font files.


5) Switch to XeLaTeX to be able to use the fonts.

-- On Linux
XeLaTeX should be available in your package repository. For example,

$ sudo apt-get intall texlive-xetex


-- On Mac
Follow these instructions: http://www.texts.io/support/0001/


-- On Overleaf
Overleaf should detect XeLaTeX on its own. If it doesn't, click on the
"gear" icon next to your name, and under "Advanced Build Options" find
"LaTeX Engine" and choose "XeLaTeX".



5) Edit tex/preamble.tex

- Tell xetex whether you have the font installed in the system (e.g. Linux or Mac) or in the main directory (Overleaf).
- Choose between E5 (small) and G5 (large) page size.
- Add any packages you need.


6) Edit constants

In thesis.tex, before "\begin{document}", edit constants with your name, thesis title, etc.


7) Edit datasheet.pdf

This is an editable PDF with a form. On Linux you can edit it with Okular,
and on Mac with Adobe Acrobat Reader. But I actually got poor results with
either software. In the end, I decided to use a free desktop publishing
(DTP) package called Scribus to insert text boxes and a scan of my signature:

		https://www.scribus.net/

If you have and know how to use some other DTP program (Adobe Illustrator,
InDesign, etc) you can use that. DTP programs do have a bit of a learning
curve, so don't expect to do this the night before the deadline. If you
decide to use DTP, you'll want to install the fonts in your computer so
you can fill-in the form with the correct font (Adobe Garamond Pro).


You will need two ISBNs for the PhD thesis, one for print and one for online
(pdf) content. This page explains how to get your ISBNs:

http://www.ub.lu.se/en/publish/registering-and-publishing-in-lup/doctoral-theses/isbn-for-a-doctoral-thesis


8) Edit tex/frontmatter.tex

The first few pages are pretty standard, but you'll probably want to make
some tweaks.


9) Write your thesis.

The rest of the thesis should be familiar LaTeX.


10) Compile thesis: xelatex thesis.tex. You need to use xelatex because of the
University fonts. If you use pdflatex, latex, lualatex, etc, it will work, but it will look ugly!

7) Compile bibtex: bibtex thesis.

8) Repeat until all labels are resolved.
You can also use TeXshop (Mac), there is a special line that advises TeXshop to compile with xelatex. 

Good luck!
