import matplotlib.pyplot as plt
import numpy as np
import csv
import math
import matplotlib.cm as cm
from mpmath import *
from scipy.stats import norm
from collections import Counter

plt.style.use('fivethirtyeight')
plt.rcParams.update({'font.size': 35})

from data_loaders import ReadPickle

from radar_rec_utils.utils.unpack_cube import unpack_cube

frame = 80
cl_width = 2
wall_distance = 2.5
factor = 0.3125

def rd_process(cube):
    ns = cube.shape[0]
    nr = cube.shape[1]
    win = np.outer(np.hanning(ns), np.hanning(nr))

    fft_size = (ns, nr)
    rd = np.fft.fft2(cube * win[:, :, np.newaxis], s=fft_size, axes=(0, 1))
    rd = np.fft.fftshift(rd, axes=(1, ))

    rd_db = 20 * np.log10(np.mean(np.abs(rd), axis=2))
    nf = np.median(rd)
    nf_db = np.median(rd_db)

    return rd, rd_db, nf, nf_db

def angle_process(rd, rd_db, peak_idx):
    ang_fft = np.fft.fft(rd[peak_idx], n = 128)
    ang_fft = np.fft.fftshift(ang_fft)
    angle_peak_idx = np.argmax(np.abs(ang_fft))

    angle = 2 * (angle_peak_idx - ang_fft.shape[0] // 2) / (ang_fft.shape[0])
    angle = np.rad2deg(np.arcsin(angle))

    return ang_fft, angle

def find_peak(range_velocity, clutter_width, factor = 0.3125):
    nv = range_velocity.shape[1]
    rv_mod = range_velocity.copy()
    rv_mod[:,nv//2-clutter_width:nv//2+clutter_width] = 0 #Set the clutter to zero
    idx = np.unravel_index(rv_mod.argmax(), rv_mod.shape)
    power = rv_mod[idx]
    distance = idx[0]*factor
    return rv_mod, power, distance, idx

def find_second_peak(range_velocity, idx, factor = 0.3125):
    rv_mod = range_velocity.copy()
    rv_mod[idx[0]-2:idx[0]+3,idx[1]-3:idx[1]+4] = 0 #Set around main peak to zero
    rv_mod[:idx[0]+1,:] = 0 #Set shorter distances to 0
    rv_mod[:,idx[1]:] = 0 #Set higher velocities to 0
    idx_2 = np.unravel_index(rv_mod.argmax(), rv_mod.shape)
    distance_second = idx_2[0] * factor
    power_2 = rv_mod[idx_2]
    return idx_2, distance_second, power_2

def inverse_wall_non_radial(d_direct, v_real, d_ghost, v_ghost, theta_ghost, theta = 0, factor = 0.3125):
    theta_rad = np.deg2rad(theta)
    theta_ghost_rad = np.deg2rad(theta_ghost)
    b = 4*d_direct*math.sin(theta_rad) # b in quadratic equation
    d_wall_d = factor/8 * (b + math.sqrt(b**2-16*(d_direct**2-d_ghost**2)))
    arg = math.acos(v_ghost/v_real) - theta_rad
    d_wall_v = factor/2 * d_direct * (math.cos(theta_rad)*math.tan(arg)+math.sin(theta_rad))
    d_wall_angle = factor/2 * d_direct * (math.cos(theta_rad)*math.tan(theta_ghost_rad) + math.sin(theta_rad))
    return d_wall_d, d_wall_v, d_wall_angle

def find_ghost_AoA_non_radial(d, d_wall = 2.5, theta = 0 ):
    arg = (2*d_wall-d*math.sin(np.deg2rad(theta)))/(d * math.cos(np.deg2rad(theta)))
    theta_ghost = np.rad2deg(math.atan(arg))
    return theta_ghost


if __name__ == '__main__':
    folder = "/home/andrenu/radar_data/2020_11_25/_raw_data_2020-11-25_10-53-24"
    reader = ReadPickle(folder)

    data = reader.read_frame(frame)
    cube = unpack_cube(data)
    cube_med = np.median(np.abs(cube.real))

    rd, rd_db, nf, nf_db = rd_process(cube)

    rv_m, power, distance, idx = find_peak(rd_db, cl_width, factor)
    idx_2, distance_ghost, power_2 = find_second_peak(rv_m, idx, factor)

    plt.figure()
    plt.imshow(rd_db, vmin=nf_db, vmax=nf_db + 40, cmap='jet', aspect='auto', origin='lower')
    plt.scatter(idx[1], idx[0], s=500, marker='x', c = 'darkorange')
    plt.scatter(idx_2[1], idx_2[0], s=500, c='green', marker='x')
    plt.xlabel('"velocity"')
    plt.ylabel('"range"')

    ang_fft, angle = angle_process(rd, rd_db, idx)

    plt.figure()
    plt.plot(20 * np.log10(np.abs(ang_fft)))
    plt.ylabel('dB')
    plt.xlabel('Anglebin')
    plt.title(f'AngleFFT (angle={angle})')

    power_list = []
    power_2_list = []
    distance_list = []
    d_wall_d_list = []
    d_wall_v_list = []
    d_wall_angle_list = []
    d_wall_av_list = []
    d_wall_1_list = []
    d_wall_2_list = []
    angle_list = []
    theta_list = []
    angle_direct_list = []
    distance_ghost_list = []
    error1_list = []
    error2_list = []
    d_wall_3_list = []


    for ind, frame in reader.read_frames():
        power_sum = []
        cube = unpack_cube(frame)

        rd, rd_db, nf, nf_db = rd_process(cube)
        rv_m, power_db, distance, idx = find_peak(rd_db, cl_width, factor)
        idx_2, distance_ghost, power_2 = find_second_peak(rv_m, idx, factor)

        ang_fft_direct, angle_direct = angle_process(rd, rd_db, idx)
        ang_fft, angle = angle_process(rd, rd_db, idx_2)
        d_wall_d, d_wall_v, d_wall_angle = inverse_wall_non_radial(idx[0], idx[1], idx_2[0], idx_2[1], angle, angle_direct, factor)
        theta_ghost = find_ghost_AoA_non_radial(distance, wall_distance, angle_direct)

        if power_db > nf_db + 20 and ind < 400:
            g_rel = ghost_rel_list[d_list_bin.index(idx[0])]
            v_rel = v_rel_list[d_list_bin.index(idx[0])]
            plt.figure(3)
            plt.clf()

            plt.subplot(121)
            plt.imshow(np.abs(cube[:, :, 0].real), vmin=cube_med, vmax=cube_med * 4, cmap='jet', aspect='auto')
            plt.xlabel('chirp')
            plt.ylabel('discrete samples')
            plt.title('Baseband')

            plt.subplot(122)
            plt.imshow(rd_db, vmin=nf_db, vmax=nf_db + 40, cmap='jet', aspect='auto')
            plt.scatter(idx[1], idx[0], s=500, c='darkorange', marker='x')
            plt.scatter(idx[1]*v_rel, idx[0]*g_rel, s=500, c='crimson', marker='x')
            plt.scatter(idx_2[1], idx_2[0], s=500, c='green', marker='x')
            plt.xlabel('"velocity"')
            plt.ylabel('"range"')
            plt.title('No repair (noise = {:.2f}dB)'.format(nf_db))

            plt.suptitle(f'Frame {ind}, {idx}')

            plt.pause(0.01)


        #disregard noise ("ind" manually chosen)
        if power_db > nf_db + 20 and ind < 360 and ind > 50 and angle > 0:
            power_list.append(power_db)
            power_2_list.append(power_2)
            distance_list.append(distance)
            d_wall_d_list.append(d_wall_d)
            d_wall_v_list.append(d_wall_v)
            d_wall_angle_list.append(d_wall_angle)
            angle_list.append(angle)
            theta_list.append(theta_ghost)
            angle_direct_list.append(angle_direct)
            distance_ghost_list.append(distance_ghost)

            

    plt.figure()#Power-Range for main peak
    plt.plot(distance_list, power_list, '-o')
    plt.xlabel('range [m]')
    plt.ylabel('power [dB]')
    log_distance_list = np.log10(distance_list)
    z = np.polyfit(log_distance_list, power_list, 1)
    x = np.linspace(min(log_distance_list), max(log_distance_list), 1000)
    plt.plot(10**x, z[0]*x + z[1])
    plt.xscale("log")
    print(z)
    plt.text(10, 110, f'slope = {np.round(z[0], 2)}', fontsize=15)

    #discern between useful data and noise:
    angle_list_reduced = []
    distance_list_reduced = []
    d_wall_d_list_reduced, d_wall_v_list_reduced, d_wall_angle_list_reduced, distance_ghost_list_reduced = [], [], [], []
    power_2_list_reduced = []
    for i in range(len(distance_list)):
        if angle_list[i] > theta_list[i] - 3 and angle_list[i] < theta_list[i] + 5: #these parameters are manually decided
            angle_list_reduced.append(angle_list[i])
            distance_list_reduced.append(distance_list[i])
            d_wall_d_list_reduced.append(d_wall_d_list[i])
            d_wall_v_list_reduced.append(d_wall_v_list[i])
            d_wall_angle_list_reduced.append(d_wall_angle_list[i])
            distance_ghost_list_reduced.append(distance_ghost_list[i])
            power_2_list_reduced.append(power_2_list[i])

    plt.figure() #Plot AoAs
    plt.plot(angle_list, distance_list, label = 'FFT ghost angle')
    plt.plot(theta_list, distance_list, linestyle = ':', label = 'theoretical angle')
    plt.xlabel('AoA [degree]')
    plt.ylabel('target distance [m]')
    plt.plot(angle_list_reduced, distance_list_reduced, linestyle = '--', label = 'noise reduced')
    plt.plot(angle_direct_list, distance_list, linestyle = '-.', label = 'FFT main angle')
    plt.legend()

    plt.figure()#Wall inference
    plt.plot(d_wall_d_list_reduced, distance_list_reduced, c = 'r', label = 'inferred from eq. 2.22')
    plt.plot(d_wall_angle_list_reduced, distance_list_reduced, c = 'g', linestyle = '-.', label = 'inferred from eq. 2.23')
    plt.plot(d_wall_v_list_reduced, distance_list_reduced, c = 'cornflowerblue', linestyle = '--', label = 'inferred from eq. 2.24')
    plt.axvline(x = 2.5, c = 'k')
    plt.xlabel('inferred distance to wall [m]')
    plt.ylabel('target distance [m]')
    plt.legend()

    #Plot in cartesian coordinate system:
    k = 0
    plt.figure()
    plt.ylim(0, 40)
    plt.xlim(-2, 11)
    plt.xlabel('x [m]')
    plt.ylabel('y [m]')
    x_list, y_list, x_ghost_list, y_ghost_list = [], [], [], []
    for i in range(len(distance_list)):
        x_list.append(distance_list[i] * math.sin(np.deg2rad(angle_direct_list[i])))
        y_list.append(distance_list[i] * math.cos(np.deg2rad(angle_direct_list[i])))
        if distance_list[i] == distance_list_reduced[k] and k < len(distance_list_reduced) - 1:
            x_ghost_list.append(distance_ghost_list_reduced[k] * math.sin(np.deg2rad(angle_list_reduced[k])))
            y_ghost_list.append(distance_ghost_list_reduced[k] * math.cos(np.deg2rad(angle_list_reduced[k])))
            k += 1
    plt.plot(x_list, y_list, '-x', c = 'r', label = 'main target')
    plt.plot(x_ghost_list, y_ghost_list, '-o', c = 'g', label = 'ghost target')
    plt.legend()
 
    plt.show()

