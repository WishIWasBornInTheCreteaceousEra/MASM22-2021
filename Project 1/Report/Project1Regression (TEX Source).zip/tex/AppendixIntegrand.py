# -*- coding: utf-8 -*-
"""
Created on Fri May 29 15:40:12 2020

@author: André Nuesslein
A swimmer creates a flow field and a passive tracer advects.
Partly to reproduce results from a paper (DOI: 10.1039/c3sm52201f).
Extension: include the Faxén Laplcian correction for non point-like tracers.
Laplacian implemented both analytically and discretely.
Also: analyze different cut-off parameters c (see paper).
The code produces results such as figure 2 in the paper.
It also creates files which list the parameter A (see paper) as a function of c.
"""

import numpy as np
from scipy.spatial import distance
import math
import matplotlib.pyplot as plt
plt.rcParams.update({'font.size': 32})

#swimmer parameters:
p = 32 #coefficient in front of the velocity field
orientation = [1, 0] #orientation of the swimmer
DT = 0.001 #time step
V = 22 #velocity of the swimmer
Lambda = 10 #average distance covered by swimmer before tumbling
Steps = int(Lambda/V/DT)
sigma = math.sqrt(p/V)

h = 0.05 #parameter for discrete Laplacian

#various initial distances between tracer and swimmer:
GridSpacing = 0.05
Beg = -30
End = 30
Length = End - Beg
num = int(Length/GridSpacing + 1)
Xi_array = np.linspace(Beg, End, num)
Chi_array = np.linspace(Beg, End, num)
 
tracerInitial = np.array([0,0]) #convenient to set the tracer in the origin                     

Radius_List = [8]
C_List = [1, 3, 5, 7, 9, 11] #cut-off radius

def u(A, r, d): #velocity field (at distance r) of a swimmer placed at the 
                #origin with orientation d (equation 1 in DOI: 1019079108)      
    r_hat = r / np.linalg.norm(r)
    d_hat = d / np.linalg.norm(d)
    return A/(np.linalg.norm(r)**2) * (3*(np.dot(r_hat, d_hat))**2 - 1) * r_hat

def Laplace2D(A, Position, d, h): #Laplace of a velocity field
    Position_x1 = Position + [h,0]
    Position_x2 = Position + [-h,0]
    Position_y1 = Position + [0,h]
    Position_y2 = Position + [0,-h]
    V_x1 = u(A, Position_x1, d)
    V_x2 = u(A, Position_x2, d)
    V_y1 = u(A, Position_y1, d)
    V_y2 = u(A, Position_y2, d)
    Laplace = (V_x1 + V_x2 + V_y1 + V_y2 - 4 * u(A, Position, d))/h**2
    return Laplace

def LaplaceAnalytic(A, r, Radius): #assumes horizontal swimmer orientation
     rr = np.linalg.norm(r)
     LaplaceU = A/(rr**7)*np.array([r[0]*(3*rr**2 - 5*r[0]**2), \
                                    r[1]*(rr**2 - 5*r[0]**2)])*(Radius**2)
     return LaplaceU

def NoLaplaceDistanceWrite(radius, c):
    f = open(f'Integrand_TracerRadius_0_c_{c}.dat','w')
    for Xi in Xi_array:
        for Chi in Chi_array:
            b = Lambda * Chi
            a = sigma * np.exp(Xi)
            swimmerInitial = np.array([-b, a])
            swimmer = swimmerInitial
            tracer = tracerInitial
            for t in range(0, Steps):
                r = np.subtract(tracer, swimmer) #The position of the tracer in the coordinate system centered around the swimmer
                if np.linalg.norm(r)>c:
                    velocity = u(p, r, orientation)
                    tracer = np.add(tracer, velocity*DT)
                swimmer = np.add(swimmer, [V*DT, 0])
            d = distance.euclidean(tracer, tracerInitial)
            Integrand = np.exp(2*Xi) * d**2 / sigma**2
            f.write(f'{Chi} {Xi} {Integrand}\n')
    f.close()
    
def DiscreteLaplaceDistanceWrite(radius, c):
    f = open(f'Discrete_Laplace_Integrand_TracerRadius_{radius}_c_{c}.dat','w')
    for Xi in Xi_array:
        for Chi in Chi_array:
            b = Lambda * Chi
            a = sigma * np.exp(Xi)
            swimmerInitial = np.array([-b, a])
            swimmer = swimmerInitial
            tracer = tracerInitial
            for t in range(0, Steps):
                r = np.subtract(tracer, swimmer) #The position of the tracer in
                            #the coordinate system centered around the swimmer
                if np.linalg.norm(r)>c:
                    velocity = u(p, r, orientation)
                    Laplaced = Laplace2D(p, r, orientation, h)
                    FaxVelocity = velocity + radius**2/6*Laplaced
                    tracer = np.add(tracer, FaxVelocity*DT)
                swimmer = np.add(swimmer, [V*DT, 0])
            d = distance.euclidean(tracer, tracerInitial)
            Integrand = np.exp(2*Xi) * d**2 / sigma**2
            f.write(f'{Chi} {Xi} {Integrand}\n')
    f.close()

def AnalyticLaplaceDistanceWrite(radius, c):
    f = open(f'Analytic_Laplace_Integrand_TracerRadius_{radius}_c_{c}.dat','w')
    for Xi in Xi_array:
        for Chi in Chi_array:
            b = Lambda * Chi
            a = sigma * np.exp(Xi)
            swimmerInitial = np.array([-b, a])
            swimmer = swimmerInitial
            tracer = tracerInitial
            for t in range(0, Steps):
                r = np.subtract(tracer, swimmer) #The position of the tracer in
                            #the coordinate system centered around the swimmer
                if np.linalg.norm(r)>c:
                    velocity = u(p, r, orientation)
                    LaplaceU = LaplaceAnalytic(p, r, radius)
                    FaxVelocity = velocity + LaplaceU
                    tracer = np.add(tracer, FaxVelocity*DT)
                swimmer = np.add(swimmer, [V*DT, 0])
            d = distance.euclidean(tracer, tracerInitial)
            Integrand = np.exp(2*Xi) * d**2 / sigma**2
            f.write(f'{Chi} {Xi} {Integrand}\n')
    f.close()

def ComputeIntegral(FileName):
    Sum = 0
    with open(FileName,'r') as f:
        for line in f:
            values = [float(s) for s in line.split()]
            Sum += values[2]
    Integral = Sum*Length**2/num**2
    return Integral

X, Y = np.meshgrid(Chi_array, Xi_array)


for radius in Radius_List:
    f = open(f'Discrete_Laplace_Integrand_TracerRadius_{radius}.dat','w')
    f.write('c A \n')
    g = open(f'Analytic_Laplace_Integrand_TracerRadius_{radius}.dat','w')
    g.write('c A \n')
    for c in C_List:
        #discrete verison:
        DiscreteLaplaceDistanceWrite(radius, c)
        Integral = ComputeIntegral(f'Discrete_Laplace_Integrand_TracerRadius_{radius}_c_{c}.dat')
        A = np.pi/3*Integral
        f.write(f'{c} {A}\n')

        Data = np.loadtxt(f'Discrete_Laplace_Integrand_TracerRadius_{radius}_c_{c}.dat', delimiter=' ')
        Z = np.array(np.split(Data[:,2], len(X)))
        
        fig = plt.figure(figsize=(6,5))
        left, bottom, width, height = 0.1, 0.1, 0.8, 0.8
        ax = fig.add_axes([left, bottom, width, height])
        
        cp = plt.contourf(X, Y, Z, 500, cmap = 'gist_stern')
        plt.colorbar(cp)
        
        ax.set_ylim(-6, 6)
        ax.set_xlim(-4.5, 4.5)
        ax.set_title(f'r = {radius}, Discrete, DT = {DT}, num = {num}, from {Beg} to {End}, A = {A}, c = {c}')
        ax.set_xlabel('\u03C7 = b/\u03BB')
        ax.set_ylabel('\u03BE = log(a/\u03C3)')
        plt.show()
        #analytic verison:
        AnalyticLaplaceDistanceWrite(radius, c)
        Integral = ComputeIntegral(f'Analytic_Laplace_Integrand_TracerRadius_{radius}_c_{c}.dat')
        A = np.pi/3*Integral
        g.write(f'{c} {A}\n')

        Data = np.loadtxt(f'Analytic_Laplace_Integrand_TracerRadius_{radius}_c_{c}.dat', delimiter=' ')
        Z = np.array(np.split(Data[:,2], len(X)))
        
        fig = plt.figure(figsize=(6,5))
        left, bottom, width, height = 0.1, 0.1, 0.8, 0.8
        ax = fig.add_axes([left, bottom, width, height])
        
        cp = plt.contourf(X, Y, Z, 500, cmap = 'gist_stern')
        plt.colorbar(cp)
        
        ax.set_ylim(-6, 6)
        ax.set_xlim(-4.5, 4.5)
        ax.set_title(f'r = {radius}, Analytic, DT = {DT}, num = {num}, from {Beg} to {End}, A = {A}, c = {c}')
        ax.set_xlabel('\u03C7 = b/\u03BB')
        ax.set_ylabel('\u03BE = log(a/\u03C3)')
        plt.show()
    f.close()
    g.close()